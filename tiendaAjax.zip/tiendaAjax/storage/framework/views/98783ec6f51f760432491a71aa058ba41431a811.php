<?php $__env->startSection('content'); ?>

<!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="500">
      <h1>Welcome to Sportium Shop</h1>
      <h2>Become your sport live</h2>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left">
            <img src="assets/img/bg2.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right">
            <h3>Who we are and how we got here.</h3>
            <p class="fst-italic">
              We created the company from doing business with our partner Eui-Jo Hwan, a great friend and one of the largest suppliers in all of Korea.
            </p>
            <ul>
              <li><i class="bi bi-check-circle"></i> We bought a first batch and sold it in Granada.</li>
              <li><i class="bi bi-check-circle"></i> Our second office was created in Seville and then in Madrid.</li>
              <li><i class="bi bi-check-circle"></i> We have 3 international headquarters with the possibility of establishing a factory in Korea.</li>
            </ul>
            <p>
              We have expanded our sponsors and we have very famous brands.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->


    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients">
      <div class="container" data-aos="zoom-in">

        <div class="row d-flex align-items-center">

          <div class="col-lg-2 col-md-4 col-6">
            <img src="assets/img/clients/nike.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="assets/img/clients/adidas.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="assets/img/clients/puma.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="assets/img/clients/hollister.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="assets/img/clients/vans.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6">
            <img src="assets/img/clients/fila.png" class="img-fluid" alt="">
          </div>

        </div>

      </div>
    </section><!-- End Clients Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="row">
          <div class="col-lg-6 col-md-6 d-flex align-items-stretch" data-aos="fade-up">
            <a href="<?php echo e(url('clothesgenre/'. 1)); ?>"><div class="icon-box man">
              <h4>MAN</h4>
            </div></a>
          </div>

          <div class="col-lg-6 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="150">
            <a href="<?php echo e(url('clothesgenre/'. 2)); ?>"><div class="icon-box woman">
              <h4>WOMAN</h4>
            </div></a>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

  </main><!-- End #main -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('tienda.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda/resources/views/tienda/index.blade.php ENDPATH**/ ?>