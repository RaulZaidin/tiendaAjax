<?php $__env->startSection('content'); ?>

<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
          <li>Product Details</li>
        </ol>
        <h2><?php echo e($clothe -> name); ?></h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-8">
            <div class="portfolio-details-slider swiper">
              <div class="swiper-wrapper align-items-center">

                <div class="swiper">
                  <img src="../images/<?php echo e($clothe->images->file); ?>" alt="">
                </div>

              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="portfolio-info">
              <h3>Product information</h3>
              <ul>
                <li><strong>Category</strong>: <?php echo e($clothe->categories->name); ?></li>
                <li><strong>Price</strong>: <?php echo e($clothe->price); ?>€</li>
              </ul>
            </div>
            <div class="portfolio-description">
              <h2>Description of <?php echo e($clothe->name); ?></h2>
              <p>
                <?php echo e($clothe->description); ?>

              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Details Section -->

  </main><!-- End #main -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('tienda.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda/resources/views/tienda/product.blade.php ENDPATH**/ ?>