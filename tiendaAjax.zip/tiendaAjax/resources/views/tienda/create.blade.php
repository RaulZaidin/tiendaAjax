@extends('tienda.app')

@section('content')


<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                    <section class="page-section" id="contact">
            <div class="container">
                <form id="Form" action="store" enctype="multipart/form-data" method="post">
                    @csrf
                    <div class="row align-items-stretch mb-5">
                        <div class="col-md-6" style="margin-top:20px">
                            <input type="file" name="file" id="file"/>
                        </div>
                    </div>
                    
                    <div class="text-center"><button class="btn btn-primary btn-xl text-uppercase" id="submitButton" type="submit">Crear Reseña</button></div>
                </form>
            </div>
        </section>

                </div>
            </div>
        </section>
        
        @endsection