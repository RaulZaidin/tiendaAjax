@extends('tienda.app')

@section('content')

<section class="page-section bg-light" id="portfolio">
            <div class="container">
                <div class="row">
                     @foreach($clothes as $clothe)
                
                        
                    <div class="col-lg-4 col-sm-6 mb-4" style="width:300px;margin-left:10px;padding:15px;box-shadow: 0px 0 30px rgb(25 25 25 / 8%);">
                        <!-- Portfolio item 1-->
                        <a href="{{route('showProduct', $clothe)}}">
                        <div class="portfolio-item">
                            
                                <img class="img-fluid" src="./images/{{ $clothe->images->file }}" alt="Product" style="height:250px;width:100%" />
                            
                            <div class="portfolio-caption">
                                <div class="portfolio-caption-heading">{{$clothe->name}}</div>
                                <div class="portfolio-caption-subheading text-muted">{{$clothe->price}}€</div>
                            </div>
                        </div>
                        </a>
                    </div>
                 @endforeach
                {{$clothes->links("pagination::bootstrap-4")}}
                </div>
            </div>
        </section>

@endsection